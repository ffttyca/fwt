import pytest
from selenium import webdriver
from iWebSNS.pytest_f.config.testconfig import url,driver_path
import time


@pytest.fixture(scope='function')
def test_logsystem(request):
    browser = webdriver.Firefox(executable_path=driver_path)
    browser.get(url)
    browser.maximize_window()
    browser.implicitly_wait(10)  # 隐形等待
    # time.sleep(2)
    yield browser
    browser.quit()


@pytest.fixture(scope='function')
def test_login(request):
    browser = webdriver.Firefox(executable_path=driver_path)
    browser.get(url)
    browser.maximize_window()
    browser.implicitly_wait(10)
    browser.find_element_by_name("login_email").send_keys("804313675@qq.com")
    browser.find_element_by_name("login_pws").send_keys("123456")
    browser.find_element_by_id("loginsubm").click()
    yield browser
    browser.quit()




