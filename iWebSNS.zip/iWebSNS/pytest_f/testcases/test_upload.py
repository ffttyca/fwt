from iWebSNS.pytest_f.testpageobjects.testuploadObject import TestuploadPage
from iWebSNS.pytest_f.config.testconfig import datafile_path
from iWebSNS.pytest_f.data.read_write import ReadWrite
from iWebSNS.pytest_f.log.log import logger
from selenium.webdriver.support.select import Select
import time
import pytest
from selenium import webdriver

class Testupload:
    @pytest.mark.iwebsns
    def test_1_upload(self,test_login):
        self.page1 = TestuploadPage(test_login)
        try:
            self.page1.click_mypage()
            self.page1.click_album()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_upload()
            self.page1.choosealbum()
            self.page1.click_cut()
            time.sleep(2)
            elem = self.page1.browser.find_element_by_id("album_name")
            Select(elem).select_by_value('2333')
            time.sleep(2)
            self.page1.browser.find_element_by_id("attach[]").send_keys(r"C:\Users\DELL\Desktop\151.jpeg")
            time.sleep(2)
            self.page1.click_sum()
            self.page1.click_btn()

            assert "点击右键设置访问权限" in self.page1.get_list()
            print("验证成功")

        except AssertionError:
            print("验证失败！")


    @pytest.mark.iwebsns
    def test_2_upload(self,test_login):
        self.page1 = TestuploadPage(test_login)
        try:
            self.page1.click_mypage()
            self.page1.click_album()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_upload()
            self.page1.choosealbum()
            self.page1.click_cut()
            time.sleep(2)
            self.page1.browser.find_element_by_id("attach[]").send_keys(r"C:\Users\DELL\Desktop\151.jpeg")
            time.sleep(2)
            self.page1.click_sum()
            self.page1.browser.switch_to.default_content()
            assert "请选择相册,或选择创建新相册！" in self.page1.get_photo()
            print("验证成功")

        except AssertionError:
            print("验证失败！")




