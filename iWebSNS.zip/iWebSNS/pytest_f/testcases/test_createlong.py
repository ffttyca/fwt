from iWebSNS.pytest_f.testpageobjects.testcreatelogObject import TestCreatelogPage
from iWebSNS.pytest_f.config.testconfig import datafile_path
from iWebSNS.pytest_f.data.read_write import ReadWrite
from iWebSNS.pytest_f.log.log import logger
import time
import pytest
from selenium import webdriver

class TestCreatelog:
    @pytest.mark.iwebsns
    def test_1_log(self,test_login):
        self.page1 = TestCreatelogPage(test_login)
        try:
            self.page1.click_mypage()
            time.sleep(2)
            self.page1.click_log()
            time.sleep(2)
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.create_a_log()
            time.sleep(2)
            self.page1.type_title("111")
            time.sleep(1)
            self.page1.type_tag("2222")
            time.sleep(1)
            self.page1.type_content("3333")
            time.sleep(2)
            self.page1.browser.switch_to.parent_frame()
            self.page1.browser.switch_to.default_content()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_submit()
            time.sleep(2)
            assert '创建日志成功！' in self.page1.get_list()
            print("验证成功！")
        except AssertionError:
            print("验证失败！")

    @pytest.mark.iwebsns
    def test_2_log(self,test_login):
        self.page1 = TestCreatelogPage(test_login)
        try:
            self.page1.click_mypage()
            time.sleep(2)
            self.page1.click_log()
            time.sleep(2)
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.create_a_log()
            time.sleep(1)
            self.page1.type_tag("2222")
            time.sleep(1)
            self.page1.type_content("3333")
            time.sleep(2)
            self.page1.browser.switch_to.parent_frame()
            self.page1.browser.switch_to.default_content()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_submit()
            self.page1.browser.switch_to.default_content()
            time.sleep(2)
            assert '请填写标题' in self.page1.get_title()
            print("提示成功！")
        except AssertionError:
            print("提示失败！")