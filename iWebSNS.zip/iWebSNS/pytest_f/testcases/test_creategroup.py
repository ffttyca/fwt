from iWebSNS.pytest_f.testpageobjects.testcreategroupObject import TestgroupPage
from iWebSNS.pytest_f.config.testconfig import datafile_path
from iWebSNS.pytest_f.data.read_write import ReadWrite
from iWebSNS.pytest_f.log.log import logger
import time
from selenium.webdriver.support.select import Select
import pytest
from selenium import webdriver


class Testcreategroup:
    @pytest.mark.iwebsns
    def test_1_group(self,test_login):
        self.page1 = TestgroupPage(test_login)
        try:
            self.page1.click_mypage()
            self.page1.click_group()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_c_group()
            self.page1.type_gname('1111')
            self.page1.type_introduce('111')
            self.page1.type_tag('11')
            elem = self.page1.browser.find_element_by_id("group_type")
            time.sleep(2)
            Select(elem).select_by_value('14')
            time.sleep(2)
            self.page1.click_create()
            assert self.page1.get_list()
            print("创建群组成功")

        except AssertionError:
            print("创建群组失败")

    @pytest.mark.iwebsns
    def test_2_group(self,test_login):
        self.page1 = TestgroupPage(test_login)
        try:
            self.page1.click_mypage()
            self.page1.click_group()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_c_group()
            time.sleep(1)
            self.page1.type_introduce('111')
            time.sleep(2)
            self.page1.type_tag('11')
            time.sleep(2)
            self.page1.click_create()
            self.page1.browser.switch_to.default_content()
            assert "请认真填写每个选项" in self.page1.get_msg()
            print("错误类别验证成功")

        except AssertionError:
            print("错误类别验证失败")








