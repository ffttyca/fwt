from iWebSNS.pytest_f.testpageobjects.testcreatealbumObject import TestcreatealbumPage
from iWebSNS.pytest_f.config.testconfig import datafile_path
from iWebSNS.pytest_f.data.read_write import ReadWrite
from iWebSNS.pytest_f.log.log import logger
import time
import pytest
from selenium import webdriver

class Testcreatealbum:
    @pytest.mark.iwebsns
    def test_1_createalbum(self,test_login):
        self.page1 = TestcreatealbumPage(test_login)
        try:
            self.page1.click_mypage()
            self.page1.click_album()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_createalbum()
            self.page1.type_albumname("11111")
            time.sleep(2)
            self.page1.type_albumdescribe("1111")
            time.sleep(1)
            self.page1.type_albumlabel("111")
            time.sleep(1)
            self.page1.click_create()
            assert '创建相册成功！' in self.page1.browser.title == "点击右键设置访问权限"
            print("创建相册成功！")
        except AssertionError:
            print("创建相册失败！")

    @pytest.mark.iwebsns
    def test_2_createalbum(self,test_login):
        self.page1 = TestcreatealbumPage(test_login)
        try:
            self.page1.click_mypage()
            self.page1.click_album()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_createalbum()
            self.page1.type_albumname("111112")
            time.sleep(2)
            self.page1.click_create()
            self.page1.browser.switch_to.default_content()
            assert '请正确填入相册名和描述！' in self.page1.get_msg3()
            print("提示请正确填入相册名和描述成功")
        except AssertionError:
            print("提示请正确填入相册名和描述失败！")









