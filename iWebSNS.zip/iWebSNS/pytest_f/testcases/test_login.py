from iWebSNS.pytest_f.testpageobjects.testloginObject import TestLoginPage
from iWebSNS.pytest_f.config.testconfig import datafile_path
from iWebSNS.pytest_f.data.read_write import ReadWrite
from iWebSNS.pytest_f.log.log import logger
import time
import pytest


class TestLogin:
    # @pytest.mark.iwebsns
    def test_1_login(self,test_logsystem):
        self.page1=TestLoginPage(test_logsystem)
        file=ReadWrite(datafile_path)
        userlist=file.read()
        user=userlist[0]
        try:
            self.page1.type_username(user[0])
            self.page1.type_password(user[1])
            self.page1.click_login()
            self.page1.click_logout()
            time.sleep(2)
            print(self.page1.get_pwdtext())
            assert self.page1.get_pwdtext() == "我的主页"
            print("登录成功！")
        except AssertionError:
            print("登录失败！")



    # @pytest.mark.iwebsns
    def test_2_login(self,test_logsystem):
        self.page1=TestLoginPage(test_logsystem)
        file=ReadWrite(datafile_path)
        userlist=file.read()
        user=userlist[1]
        print(user[0])
        try:
            self.page1.type_username(user[0])
            self.page1.type_password(user[1])
            self.page1.click_login()
            time.sleep(3)
            print(self.page1.get_pwdtext())
            assert '用户密码错误!' in self.page1.get_pwdtext()
            print("错误密码验证成功！")
        except AssertionError:
            print("错误密码验证失败！")


# if __name__=='__main__':
#     pytest.main('-sv','test_login.py')


    # def test_2_login(self,test_logsystem):
    #     self.page1=TestLogPage(test_logsystem)
    #     self.page1.type_username('zxl')
    #     self.page1.click_login()
    #     try:
    #         time.sleep(2)
    #         alert =self.page1.browser.switch_to.alert
    #         text = alert.text
    #         # promp = Alert(self.browser)
    #         # text = promp.text()
    #         assert "登录失败" in text
    #         print("测试用例成功：显示登录失败提示信息！")
    #         # self.assertIn("登录失败",text)
    #         logger.info("验证用户登录失败信息.......")
    #     except AssertionError:
    #         # promp.accept()
    #         alert.accept()
    #         print("测试用例失败：异常情况！")
    #         logger.info("验证用户登录失败信息.......")

