from iWebSNS.pytest_f.testpageobjects.testeditcategoryObject import TesteditcategoryPage
from iWebSNS.pytest_f.config.testconfig import datafile_path
from iWebSNS.pytest_f.data.read_write import ReadWrite
from iWebSNS.pytest_f.log.log import logger
from selenium.webdriver.support.select import Select
import time
import pytest
from selenium import webdriver

class TestEdit:
    @pytest.mark.iwebsns
    def test_1_edit(self,test_login):
        self.page1 = TesteditcategoryPage(test_login)
        try:
            self.page1.click_mypage()
            time.sleep(2)
            self.page1.click_log()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.create_11_log()
            self.page1.get_bj()
            # self.page1.browser.switch_to.frame("frame_content")
            time.sleep(2)
            elem = self.page1.browser.find_element_by_name("blog_sort_list")
            time.sleep(2)
            Select(elem).select_by_value('2179')
            time.sleep(2)
            self.page1.click_sub()
            assert self.page1.get_list2()
            print("编辑分类成功！")
        except AssertionError:
            print("编辑分类失败！")

    @pytest.mark.iwebsns
    def test_2_edit(self,test_login):
        self.page1 = TesteditcategoryPage(test_login)
        try:
            self.page1.click_mypage()
            time.sleep(2)
            self.page1.click_log()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.create_11_log()
            time.sleep(1)
            self.page1.get_bj()
            # self.page1.browser.switch_to.frame("frame_content")
            time.sleep(2)
            elem = self.page1.browser.find_element_by_name("blog_sort_list")
            time.sleep(2)
            Select(elem).select_by_value('2289')
            time.sleep(2)
            self.page1.click_sub()
            assert self.page1.get_list2()
            print("编辑分类成功！")
        except AssertionError:
            print("编辑分类失败！")

