from iWebSNS.pytest_f.testpageobjects.testgroupsearchObject import TestgroupsearchPage
from iWebSNS.pytest_f.config.testconfig import datafile_path
from iWebSNS.pytest_f.data.read_write import ReadWrite
from iWebSNS.pytest_f.log.log import logger
from selenium.webdriver.support.select import Select
import time
import pytest
from selenium import webdriver

class Testgroupsearch:
    @pytest.mark.iwebsns
    def test_1_group(self,test_login):
        self.page1 = TestgroupsearchPage(test_login)
        try:
            self.page1.click_mypage()
            self.page1.click_group()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_groupsearch()
            self.page1.type_gruopname('黎明杀机')
            time.sleep(2)
            self.page1.type_grouptag('恐怖游戏')
            time.sleep(1)
            elem = self.page1.browser.find_element_by_id("group_type")
            time.sleep(2)
            Select(elem).select_by_value('13')
            time.sleep(2)
            self.page1.click_search()
            assert self.page1.get_list()
            print("查找群组成功")
        except AssertionError:
            print("查找群组失败")

    @pytest.mark.iwebsns
    def test_2_group(self, test_login):
        self.page1 = TestgroupsearchPage(test_login)
        try:
            self.page1.click_mypage()
            self.page1.click_group()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_groupsearch()
            self.page1.type_gruopname('黎明杀机')
            time.sleep(2)
            self.page1.type_grouptag('11')
            time.sleep(1)
            elem = self.page1.browser.find_element_by_id("group_type")
            time.sleep(2)
            Select(elem).select_by_value('13')
            time.sleep(2)
            self.page1.click_search()
            assert "重新搜索" in self.page1.get_flist()
            print("验证成功")
        except AssertionError:
            print("验证失败")





