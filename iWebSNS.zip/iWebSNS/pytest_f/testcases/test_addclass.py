from iWebSNS.pytest_f.testpageobjects.testaddclassObject import TestaddclassPage
from iWebSNS.pytest_f.config.testconfig import datafile_path
from iWebSNS.pytest_f.data.read_write import ReadWrite
from iWebSNS.pytest_f.log.log import logger
import time
import pytest
from selenium import webdriver

class Testaddclass:
    @pytest.mark.iwebsns
    def test_1_addclass(self,test_login):
        self.page1 = TestaddclassPage(test_login)
        try:
            self.page1.click_mypage()
            time.sleep(2)
            self.page1.click_log()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_a_log()
            time.sleep(1)
            self.page1.get_bj()
            time.sleep(1)
            self.page1.click_add()
            time.sleep(1)
            self.page1.type_add("生活")
            time.sleep(1)
            self.page1.click_save()
            time.sleep(2)
            assert '编辑分类成功！' in self.page1.get_list2()
            print("编辑分类成功！")
        except AssertionError:
            print("编辑分类失败！")

    @pytest.mark.iwebsns
    def test_2_addclass(self,test_login):
        self.page1 = TestaddclassPage(test_login)
        try:
            self.page1.click_mypage()
            time.sleep(2)
            self.page1.click_log()
            self.page1.browser.switch_to.frame("frame_content")
            self.page1.click_a_log()
            time.sleep(1)
            self.page1.get_bj()
            time.sleep(1)
            self.page1.click_add()
            time.sleep(1)
            self.page1.click_save()
            self.page1.browser.switch_to.default_content()
            assert '请填写信息' in self.page1.get_msg()
            print("提示成功！")
        except AssertionError:
            print("提示失败！")