from selenium.webdriver.common.by import By
# from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.select import Select
import time
class TestgroupPage:
    def __init__(self,driver):
        self.browser = driver
        self.mypage = By.XPATH, "//a[text()='我的主页']"
        self.group = By.LINK_TEXT,'群 组'
        self.c_group = By.LINK_TEXT,'创建群组'
        self.g_id = By.ID,'group_name'
        self.g_introduce = By.ID,'group_resume'
        self.g_tag = By.ID,'tag'
        self.g_sub = By.ID,'UploadButton'
        self.g_type = By.ID,'group_type'
        self.g_list = By.CSS_SELECTOR,'[class=group_list]'
        self.g_msg = By.ID,'Message_undefined'


    def click_mypage(self):
        self.browser.find_element(*self.mypage).click()

    def click_group(self):
        self.browser.find_element(*self.group).click()

    def click_c_group(self):
        self.browser.find_element(*self.c_group).click()

    def type_gname(self,name):
        self.browser.find_element(*self.g_id).send_keys(name)

    def type_introduce(self,body):
        self.browser.find_element(*self.g_introduce).send_keys(body)

    def type_tag(self,tagbody):
        self.browser.find_element(*self.g_tag).send_keys(tagbody)

    def click_create(self):
        self.browser.find_element(*self.g_sub).click()


    def get_list(self):
        self.browser.find_element(*self.g_list).click()

    def get_msg(self):
        msg = self.browser.find_element(*self.g_msg).text
        return msg







