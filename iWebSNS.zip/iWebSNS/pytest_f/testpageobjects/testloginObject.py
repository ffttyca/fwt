from selenium.webdriver.common.by import By

class TestLoginPage:
    def __init__(self,driver):
        self.username=By.NAME,'login_email'
        self.password=By.NAME,'login_pws'
        self.login=By.ID,'loginsubm'
        self.browser=driver
        self.logout=By.LINK_TEXT,'退出'
        self.pwdmsg = By.CSS_SELECTOR, 'p>label>span[id=pwdmsg]'
        self.mypage=By.LINK_TEXT,"我的主页"

    def type_username(self,username):
        self.browser.find_element(*self.username).send_keys(username)

    def type_password(self,password):
        self.browser.find_element(*self.password).send_keys(password)

    def click_login(self):
        self.browser.find_element(*self.login).click()

    def click_logout(self):
        self.browser.find_element(*self.logout).click()

    def get_pwdtext(self):
        msg=self.browser.find_element(*self.pwdmsg).text
        return msg



