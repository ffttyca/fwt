from selenium.webdriver.common.by import By
class TestCreatelogPage:
    def __init__(self,driver):
        self.browser=driver
        self.mypage=By.XPATH,"//a[text()='我的主页']"
        self.log=By.LINK_TEXT,'日 志'
        self.createlog=By.LINK_TEXT,'新建日志'
        self.title=By.NAME,'blog_title'
        self.tag=By.NAME,'tag'
        self.content=By.CSS_SELECTOR,'[class=ke-iframe]'
        self.submit=By.CSS_SELECTOR,'[class=regular-btn]'
        self.mylist=By.CSS_SELECTOR,'[class=log_list]'
        self.body = By.CSS_SELECTOR,'[id=Message_undefined]'



    def click_mypage(self):
        self.browser.find_element(*self.mypage).click()

    def click_log(self):
        self.browser.find_element(*self.log).click()

    def create_a_log(self):
        self.browser.find_element(*self.createlog).click()

    def type_title(self,titlename):
        self.browser.find_element(*self.title).send_keys(titlename)

    def type_tag(self,tagname):
        self.browser.find_element(*self.tag).send_keys(tagname)

    def type_content(self,content):
        self.browser.find_element(*self.content).send_keys(content)

    def click_submit(self):
        self.browser.find_element(*self.submit).click()

    def get_list(self):
        a=self.browser.find_element(*self.mylist).text
        return a

    def get_title(self):
        msg2 = self.browser.find_element(*self.body).text
        return msg2








