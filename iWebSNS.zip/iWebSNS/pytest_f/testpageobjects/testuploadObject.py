from selenium.webdriver.common.by import By
class TestuploadPage:
    def __init__(self,driver):
        self.browser = driver
        self.mypage = By.XPATH, "//a[text()='我的主页']"
        self.album = By.LINK_TEXT, '相 册'
        self.upload = By.LINK_TEXT,'上传相片'
        self.cut = By.LINK_TEXT,'切换上传方式'
        self.choose = By.CSS_SELECTOR,'[class="med-text"]'
        self.regular = By.CSS_SELECTOR,'[class=regular-btn]'
        self.xzxc = By.ID,'album_name'   #选择相册
        self.sub = By.CSS_SELECTOR,'[class=regular-btn]'  #上传确定
        self.isns = By.CSS_SELECTOR,'[class=list_album]'
        self.btn = By.NAME,'action'
        # self.msg = By.LINK_TEXT,'请选择相册,或选择创建新相册！'
        self.bbb = By.CSS_SELECTOR,'[id=_ButtonCancel_0]'
        self.photo = By.ID,'Message_undefined'



    def click_mypage(self):
        self.browser.find_element(*self.mypage).click()

    def click_album(self):
        self.browser.find_element(*self.album).click()

    def click_upload(self):
        self.browser.find_element(*self.upload).click()

    def click_cut(self):
        self.browser.find_element(*self.cut).click()

    def click_chooseup(self,):
        self.browser.find_element(*self.choose).click()

    def click_regular(self):
        self.browser.find_element(*self.regular).click()

    def choosealbum(self):
        self.browser.find_element(*self.xzxc).click()

    def click_sum(self):
        self.browser.find_element(*self.sub).click()

    def get_list(self):
        msg=self.browser.find_element(*self.isns).text
        return msg

    def click_btn(self):
        self.browser.find_element(*self.btn).click()

    # def msg2(self):
    #     msg3 = self.browser.find_element(*self.msg).text
    #     return msg3

    def click_su(self):
        self.browser.find_element(*self.bbb).click()

    def get_photo(self):
        mg3=self.browser.find_element(*self.photo).text
        return mg3



