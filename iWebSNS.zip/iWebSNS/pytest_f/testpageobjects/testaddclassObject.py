from selenium.webdriver.common.by import By
class TestaddclassPage:
    def __init__(self,driver):
        self.browser = driver
        self.mypage = By.XPATH, "//a[text()='我的主页']"
        self.log = By.LINK_TEXT, '日 志'
        self.clicklog = By.LINK_TEXT, '111'
        self.title = By.NAME, 'blog_title'
        self.add = By.LINK_TEXT,'添加分类'
        self.typeadd = By.ID,'new_sort_name'
        self.tag = By.NAME, 'tag'
        self.submit = By.CSS_SELECTOR, '[class=regular-btn]'
        self.mylist = By.CSS_SELECTOR, '[class=log_list]'
        self.save = By.CSS_SELECTOR,'[class=small-btn]'
        self.list = By.ID,'blog_sort_list'
        self.msg = By.ID,'Message_undefined'
        self.bj = By.LINK_TEXT,'编辑'



    def click_mypage(self):
        self.browser.find_element(*self.mypage).click()

    def click_log(self):
        self.browser.find_element(*self.log).click()

    def click_a_log(self):
        self.browser.find_element(*self.clicklog).click()

    def type_tag(self,tagname):
        self.browser.find_element(*self.tag).send_keys(tagname)

    def click_submit(self):
        self.browser.find_element(*self.submit).click()

    def click_add(self):
        self.browser.find_element(*self.add).click()

    def type_add(self,addname):
        self.browser.find_element(*self.typeadd).send_keys(addname)

    def click_save(self):
        self.browser.find_element(*self.save).click()

    def get_list2(self):
        msg=self.browser.find_element(*self.list).text
        return msg

    def get_msg(self):
        msg2 = self.browser.find_element(*self.msg).text
        return msg2

    def get_bj(self):
        self.browser.find_element(*self.bj).click()




