from selenium.webdriver.common.by import By
# from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.select import Select
import time

class TestgroupsearchPage:
    def __init__(self,driver):
        self.browser = driver
        self.mypage = By.XPATH, "//a[text()='我的主页']"
        self.group = By.LINK_TEXT,'群 组'
        self.gs_search = By.LINK_TEXT,'搜索群组'
        self.ty_name = By.ID,'group_name'
        self.ty_tag = By.ID,'tag'
        self.sub = By.CSS_SELECTOR,'[class=regular-btn]'
        self.g_list = By.CSS_SELECTOR, '[class=group_list]'
        self.gf_list = By.LINK_TEXT,'重新搜索'






    def click_mypage(self):
        self.browser.find_element(*self.mypage).click()

    def click_group(self):
        self.browser.find_element(*self.group).click()

    def click_groupsearch(self):
        self.browser.find_element(*self.gs_search).click()

    def type_gruopname(self,name):
        self.browser.find_element(*self.ty_name).send_keys(name)

    def type_grouptag(self,tag):
        self.browser.find_element(*self.ty_tag).send_keys(tag)

    def click_search(self):
        self.browser.find_element(*self.sub).click()

    def get_list(self):
        self.browser.find_element(*self.g_list).click()

    def get_flist(self):
        msg = self.browser.find_element(*self.gf_list).text
        return msg
