from selenium.webdriver.common.by import By
class TestcreatealbumPage:
    def __init__(self,driver):
        self.browser = driver
        self.mypage = By.XPATH, "//a[text()='我的主页']"
        self.album = By.LINK_TEXT,'相 册'
        self.cre_album = By.LINK_TEXT,'新建相册'
        self.albname = By.ID,'album_name'
        self.describe = By.ID,'album_information'   #相册描述
        self.label = By.CSS_SELECTOR,'[class=med-text]'  #标签
        self.create = By.CSS_SELECTOR,'[class=regular-btn]'  #创建
        self.albumlist = By.CSS_SELECTOR,'[class=list_album]'  #验证断言
        self.msg = By.ID,'Message_undefined'





    def click_mypage(self):
        self.browser.find_element(*self.mypage).click()

    def click_album(self):
        self.browser.find_element(*self.album).click()

    def click_createalbum(self):
        self.browser.find_element(*self.cre_album).click()

    def type_albumname(self,name):
        self.browser.find_element(*self.albname).send_keys(name)

    def type_albumdescribe(self,body):
        self.browser.find_element(*self.describe).send_keys(body)

    def type_albumlabel(self,label):
        self.browser.find_element(*self.label).send_keys(label)

    def click_create(self):
        self.browser.find_element(*self.create).click()

    def get_albumlist(self):
        self.browser.find_element(*self.albumlist).click()

    def get_msg3(self):
        msg4=self.browser.find_element(*self.msg).text
        return msg4

