from selenium.webdriver.common.by import By
class TesteditcategoryPage:
    def __init__(self,driver):
        self.browser = driver
        self.mypage = By.XPATH, "//a[text()='我的主页']"
        self.log = By.LINK_TEXT, '日 志'
        self.createlog = By.LINK_TEXT,'11'
        self.classify = By.LINK_TEXT,'日志分类'
        self.loglink = By.CSS_SELECTOR,'[class=log_edit_link]'
        self.type = By.ID,'change_sort_1532'
        self.editsave = By.CSS_SELECTOR,'[class=small-btn]'
        self.editlist = By.ID,'show_info_1532'
        self.dellog = By.CSS_SELECTOR,'[class=log_del_link]'
        self.dellink = By.LINK_TEXT,'是否删除?'
        self.tag = By.NAME, 'tag'
        self.content = By.CSS_SELECTOR, '[class=ke-iframe]'
        self.clicklog = By.LINK_TEXT, '111'
        self.bj = By.LINK_TEXT, '编辑'
        self.add = By.LINK_TEXT, '添加分类'
        self.typeadd = By.ID, 'new_sort_name'
        self.save = By.CSS_SELECTOR, '[class=small-btn]'
        self.list = By.CSS_SELECTOR,'[class=log_list]'
        self.msg = By.ID, 'Message_undefined'
        self.sub = By.CSS_SELECTOR,'[class=regular-btn]'

    def click_mypage(self):
        self.browser.find_element(*self.mypage).click()

    def click_log(self):
        self.browser.find_element(*self.log).click()

    def create_11_log(self):
        self.browser.find_element(*self.createlog).click()

    def click_classify(self):
        self.browser.find_element(*self.classify).click()

    def click_loglink(self):
        self.browser.find_element(*self.loglink).click()

    def type_edit(self,typename):
        self.browser.find_element(*self.type).send_keys(typename)

    def click_editsave(self):
        self.browser.find_element(*self.editsave).click()

    def get_edit(self):
        msg2=self.browser.find_element(*self.editlist).text
        return msg2

    def click_del(self):
        self.browser.find_element(*self.dellog).click()

    def get_del(self):
        msg3=self.browser.find_element(*self.dellink).text
        return msg3
    def type_tag(self,tagname):
        self.browser.find_element(*self.tag).send_keys(tagname)

    def type_content(self,content):
        self.browser.find_element(*self.content).send_keys(content)

    def click_a_log(self):
        self.browser.find_element(*self.clicklog).click()

    def get_bj(self):
        self.browser.find_element(*self.bj).click()

    def click_add(self):
        self.browser.find_element(*self.add).click()

    def type_add(self,addname):
        self.browser.find_element(*self.typeadd).send_keys(addname)

    def click_save(self):
        self.browser.find_element(*self.save).click()

    def get_list2(self):
        msg=self.browser.find_element(*self.list).text
        return msg

    def get_msg(self):
        msg2 = self.browser.find_element(*self.msg).text
        return msg2

    def click_sub(self):
        self.browser.find_element(*self.sub).click()