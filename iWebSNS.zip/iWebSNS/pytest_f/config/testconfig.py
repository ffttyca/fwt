import sys
import os


project_file=os.path.dirname(os.path.dirname(__file__))
# sys.path.insert(0,"F:\\PyCharm2021.2\\iWebSNS\\pytest_f")
# project_file=sys.path[0]


url="http://iwebsns.pansaifei.com/index.php"
driver_path=project_file+r'\driver\geckodriver.exe'
datafile_path=project_file+r'\data\testdata.xlsx'
case_path=project_file+r'\testcases'
report_path=project_file+r'\result\report'
log_path=project_file+r'\log\log.txt'